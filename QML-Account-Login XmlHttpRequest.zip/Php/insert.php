<!--   //https://www.youtube.com/@DEV4MAC   -->
<?php

    $db_username = 'root';
    $db_password = 'xxxx';
    $db_name     = 'xxxx';
    $db_host     = 'xxxx';

    $db = mysqli_connect($db_host, $db_username, $db_password,$db_name)
        or die('could not connect to database');


    echo "Je Debute.....";
    $MotDePasse = 'xxxx';
    $PassCrypt = password_hash($MotDePasse, PASSWORD_DEFAULT);
    //$reqC = "INSERT INTO utils VALUES (NULL, 'dev4mac', '$PassCrypt', '$MotDePasse')";
    $reqC = "INSERT INTO XXXX VALUES (NULL, 'dev4mac', '$PassCrypt', '')";
    $result = mysqli_query($db,$reqC); 


	echo $result; 
     

?>
