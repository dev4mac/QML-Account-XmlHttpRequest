<!--   //https://www.youtube.com/@DEV4MAC   -->

<HTML>
<BODY>
<form action="verif.php" method="post">

    <p> -=- CONNEXION / dev4mac -=- </p>
  
    <input type="text" name="login" value="dev4mac" placeholder="Votre login">

    <div></div>
    <input type="password" name="pass" placeholder="Votre mot de passe">
    <div></div>


    <button type="submit">connexion</button>
</form>

</BODY>
</HTML>
