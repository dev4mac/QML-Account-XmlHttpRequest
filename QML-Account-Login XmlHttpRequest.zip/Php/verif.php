<!--   //https://www.youtube.com/@DEV4MAC   -->
<?php
    error_reporting(E_ALL);

$host = '127.0.0.1';
$user = 'root';
$passwd = 'xxxx';
$schema = 'xxxx';

$pdo = NULL;
$dsn = 'mysql:host=' . $host . ';dbname=' . $schema;
try
{  
   $pdo = new PDO($dsn, $user,  $passwd);
   $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch (PDOException $e)
{
   echo 'Connexion à la base impossible.';
   die();
}
$login = FALSE;
$username = $_POST['login'];
$password = $_POST['pass'];

$query = 'SELECT * FROM xxxx WHERE (login = :name)';
$values = [':name' => $username];

try
{
$res = $pdo->prepare($query);
$res->execute($values);
}
catch (PDOException $e)
{
echo 'Query error.';
die();
}

$row = $res->fetch(PDO::FETCH_ASSOC);
if (is_array($row))
{
  if (password_verify($password, $row['pass']))
  {
    $login = TRUE;
    echo "true";
  }
  else {
    echo "false";

  }

}
else
  {
    echo "false";  
  }
  
?>
